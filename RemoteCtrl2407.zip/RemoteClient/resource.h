﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 RemoteClient.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_REMOTECLIENT_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDR_MENU_RCLICK                 130
#define IDD_DLG_STATUS                  131
#define IDD_DIALOG_WATCH                133
#define IDC_BTN_TEST                    1000
#define IDC_EDIT_PORT2                  1001
#define IDC_IPADDRESS_SERV              1002
#define IDC_TREE_DIR                    1004
#define IDC_LIST_FILEINFO               1005
#define IDC_BUTTON_FILE                 1006
#define IDC_EDIT_INFO                   1007
#define IDC_BTN_STARTWATCH              1009
#define IDC_WATCH                       1010
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_DOWNLOAD                     32774
#define ID_DOWNLOAD_FILE                32775
#define ID_DELETE_FILE                  32776
#define ID_OPEN_FILE                    32777
#define ID_RUN_FILE                     32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
